
    window.addEventListener('load', function(){
        document.querySelector('.main-title').classList.add('show');
        document.querySelector('.menu-btns').classList.add('show');
    });
